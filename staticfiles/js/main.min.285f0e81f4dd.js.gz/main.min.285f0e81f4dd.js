! function (s) {
    // "use strict";
    s(".animsition").animsition({
        inClass: "fade-in",
        outClass: "fade-out",
        inDuration: 1500,
        outDuration: 800,
        linkElement: ".animsition-link",
        loading: !0,
        loadingParentElement: "html",
        loadingClass: "animsition-loading-1",
        loadingInner: '<div class="loader05"><span></span><span></span><span></span><span></span></div>',
        timeout: !1,
        timeoutCountdown: 5e3,
        onLoadEvent: !0,
        browser: ["animation-duration", "-webkit-animation-duration"],
        overlay: !1,
        overlayClass: "animsition-overlay-slide",
        overlayParentElement: "html",
        transition: function (s) {
            window.location.href = s
        }
    });
    var o = s(window).height() / 2;
    s(window).on("scroll", function () {
        s(this).scrollTop() > o ? s("#myBtn").css("display", "flex") : s("#myBtn").css("display", "none")
    }), s("#myBtn").on("click", function () {
        s("html, body").animate({
            scrollTop: 0
        }, 300)
    });
    var i = s(".container-menu-desktop"),
        e = s(".wrap-menu-desktop");
    if (s(".top-bar").length > 0) var n = s(".top-bar").height();
    else n = 0;
    s(window).scrollTop() > n ? (s(i).addClass("fix-menu-desktop"), s(e).css("top", 0)) : (s(i).removeClass("fix-menu-desktop"), s(e).css("top", n - s(this).scrollTop())), s(window).on("scroll", function () {
        s(this).scrollTop() > n ? (s(i).addClass("fix-menu-desktop"), s(e).css("top", 0)) : (s(i).removeClass("fix-menu-desktop"), s(e).css("top", n - s(this).scrollTop()))
    }), s(".btn-show-menu-mobile").on("click", function () {
        s(this).toggleClass("is-active"), s(".menu-mobile").slideToggle()
    });
    for (var a = s(".arrow-main-menu-m"), t = 0; t < a.length; t++) s(a[t]).on("click", function () {
        s(this).parent().find(".sub-menu-m").slideToggle(), s(this).toggleClass("turn-arrow-main-menu-m")
    });
    s(window).resize(function () {
        s(window).width() >= 992 && ("block" == s(".menu-mobile").css("display") && (s(".menu-mobile").css("display", "none"), s(".btn-show-menu-mobile").toggleClass("is-active")), s(".sub-menu-m").each(function () {
            "block" == s(this).css("display") && (console.log("hello"), s(this).css("display", "none"), s(a).removeClass("turn-arrow-main-menu-m"))
        }))
    }), s(".js-show-modal-search").on("click", function () {
        s(".modal-search-header").addClass("show-modal-search"), s(this).css("opacity", "0")
    }), s(".js-hide-modal-search").on("click", function () {
        s(".modal-search-header").removeClass("show-modal-search"), s(".js-show-modal-search").css("opacity", "1")
    }), s(".container-search-header").on("click", function (s) {
        s.stopPropagation()
    });
    var l = s(".isotope-grid"),
        r = s(".filter-tope-group");
    r.each(function () {
        r.on("click", "button", function () {
            var o = s(this).attr("data-filter");
            l.isotope({
                filter: o
            })
        })
    }), s(window).on("load", function () {
        l.each(function () {
            s(this).isotope({
                itemSelector: ".isotope-item",
                layoutMode: "fitRows",
                percentPosition: !0,
                animationEngine: "best-available",
                masonry: {
                    columnWidth: ".isotope-item"
                }
            })
        })
    });
    var c = s(".filter-tope-group button");
    s(c).each(function () {
        s(this).on("click", function () {
            for (var o = 0; o < c.length; o++) s(c[o]).removeClass("how-active1");
            s(this).addClass("how-active1")
        })
    }), s(".js-show-filter").on("click", function () {
        s(this).toggleClass("show-filter"), s(".panel-filter").slideToggle(400), s(".js-show-search").hasClass("show-search") && (s(".js-show-search").removeClass("show-search"), s(".panel-search").slideUp(400))
    }), s(".js-show-search").on("click", function () {
        s(this).toggleClass("show-search"), s(".panel-search").slideToggle(400), s(".js-show-filter").hasClass("show-filter") && (s(".js-show-filter").removeClass("show-filter"), s(".panel-filter").slideUp(400))
    }), s(".js-show-cart").on("click", function () {
        s(".js-panel-cart").addClass("show-header-cart")
    }), s(".js-hide-cart").on("click", function () {
        s(".js-panel-cart").removeClass("show-header-cart")
    }), s(".js-show-sidebar").on("click", function () {
        s(".js-sidebar").addClass("show-sidebar")
    }), s(".js-hide-sidebar").on("click", function () {
        s(".js-sidebar").removeClass("show-sidebar")
    }), s(".btn-num-product-down").on("click", function () {
        var o = Number(s(this).next().val());
        o > 0 && s(this).next().val(o - 1)
    }), s(".btn-num-product-up").on("click", function () {
        var o = Number(s(this).prev().val());
        s(this).prev().val(o + 1)
    }), s(".wrap-rating").each(function () {
        var o = s(this).find(".item-rating"),
            i = -1,
            e = s(this).find("input");
        s(e).val(0), s(o).on("mouseenter", function () {
            var i = o.index(this),
                e = 0;
            for (e = 0; e <= i; e++) s(o[e]).removeClass("zmdi-star-outline"), s(o[e]).addClass("zmdi-star");
            for (var n = e; n < o.length; n++) s(o[n]).addClass("zmdi-star-outline"), s(o[n]).removeClass("zmdi-star")
        }), s(o).on("click", function () {
            var n = o.index(this);
            i = n, s(e).val(n + 1)
        }), s(this).on("mouseleave", function () {
            var e = 0;
            for (e = 0; e <= i; e++) s(o[e]).removeClass("zmdi-star-outline"), s(o[e]).addClass("zmdi-star");
            for (var n = e; n < o.length; n++) s(o[n]).addClass("zmdi-star-outline"), s(o[n]).removeClass("zmdi-star")
        })
    }), s(".js-show-modal1").on("click", function (o) {
        o.preventDefault(), s(".js-modal1").addClass("show-modal1")
    }), s(".js-hide-modal1").on("click", function () {
        s(".js-modal1").removeClass("show-modal1")
    })
}(jQuery);